<?php

namespace simplerest\core\interfaces;

interface Arrayable {

    /**
     * Get the instance as an array.
     *
     * @return array
     */
     public function toArray();

}